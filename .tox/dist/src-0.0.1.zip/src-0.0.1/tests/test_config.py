import pytest

def test_something():
    a = 2
    b = 2
    assert True